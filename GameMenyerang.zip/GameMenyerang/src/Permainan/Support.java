
package Permainan;

public class Support extends Karakter {
    public Support() {
        super("Support", 100, 12);
    }
}
