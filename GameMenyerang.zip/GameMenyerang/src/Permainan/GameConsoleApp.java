package Permainan;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lenovo
 */
import java.util.Scanner;

public class GameConsoleApp {

    public static void main(String[] args) {
        System.out.println("Game dibuat oleh Andika");

        // Pilihan Menu Utama
        System.out.println("1. Mulai");
        System.out.println("2. Keluar");
        System.out.print("Pilih nomor: ");

        Scanner scanner = new Scanner(System.in);
        int menuUtama = scanner.nextInt();

        if (menuUtama == 1) {
            // Pilihan Role untuk Pemain 1
            System.out.println("Pemain 1, pilih role anda:");
            System.out.println("1. Fighter");
            System.out.println("2. Marksman");
            System.out.println("3. Witcher");
            System.out.println("4. Tank");
            System.out.println("5. Support");
            System.out.print("Pilih nomor: ");
            int roleChoice1 = scanner.nextInt();
            Karakter player1 = createPlayer(roleChoice1);

            // Pilihan Role untuk Pemain 2
            System.out.println("Pemain 2, pilih role anda:");
            System.out.println("1. Fighter");
            System.out.println("2. Marksman");
            System.out.println("3. Witcher");
            System.out.println("4. Tank");
            System.out.println("5. Support");
            System.out.print("Pilih nomor: ");
            int roleChoice2 = scanner.nextInt();
            Karakter player2 = createPlayer(roleChoice2);

            // Mulai pertempuran
            System.out.println("Pertempuran dimulai!");

            // Loop pertempuran sampai salah satu karakter kehilangan semua HP
            while (player1.getHealth() > 0 && player2.getHealth() > 0) {
                player1.attack(player2);
                if (player2.getHealth() <= 0) {
                    System.out.println(player2.getNama() + " kalah!");
                    break;
                }

                player2.attack(player1);
                if (player1.getHealth() <= 0) {
                    System.out.println(player1.getNama() + " kalah!");
                    break;
                }
            }

        } else {
            System.out.println("Game selesai. Sampai jumpa!");
        }
    }

    // Metode untuk membuat karakter sesuai dengan pilihan role
    private static Karakter createPlayer(int roleChoice) {
        switch (roleChoice) {
            case 1:
                return new Fighter();
            case 2:
                return new Marksman();
            case 3:
                return new Witcher();
            case 4:
                return new Tank();
            case 5:
                return new Support();
            default:
                System.out.println("Pilihan role tidak valid. Memilih Fighter secara default.");
                return new Fighter();
        }
    }
}


