/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Permainan;

/**
 *
 * @author lenovo
 */
// Kelas dasar untuk Karakter dengan implementasi Attacker
class Karakter implements Attacker {
    private String nama;
    private int health;
    private int attack;

    public Karakter(String nama, int health, int attack) {
        this.nama = nama;
        this.health = health;
        this.attack = attack;
    }

    // Getter dan setter
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    // Implementasi metode attack dari interface Attacker
    @Override
    public void attack(Karakter target) {
        System.out.println(nama + " menyerang " + target.getNama() + " dengan kekuatan " + attack + "!");
        target.receiveDamage(attack);
    }

    // Metode untuk menghitung kerusakan yang diterima karakter
    public void receiveDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
        System.out.println(nama + " menerima " + damage + " kerusakan. Sisa HP: " + health);
    }
}

